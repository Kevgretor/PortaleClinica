--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.3
-- Dumped by pg_dump version 9.5.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.risultati_esame DROP CONSTRAINT risultati_esame_id_esame_fkey;
ALTER TABLE ONLY public.esame DROP CONSTRAINT "esame_id_tipologiaEsame_fkey";
ALTER TABLE ONLY public.esame DROP CONSTRAINT esame_id_paziente_fkey;
ALTER TABLE ONLY public.esame DROP CONSTRAINT esame_id_medico_fkey;
ALTER TABLE ONLY public.utente DROP CONSTRAINT utente_pkey;
ALTER TABLE ONLY public.utente DROP CONSTRAINT username;
ALTER TABLE ONLY public.tipologia_di_esame DROP CONSTRAINT tipologia_di_esame_pkey;
ALTER TABLE ONLY public.risultati_esame DROP CONSTRAINT risultati_esame_pkey;
ALTER TABLE ONLY public.medico DROP CONSTRAINT medico_pkey;
ALTER TABLE ONLY public.esame DROP CONSTRAINT esame_pkey;
DROP SEQUENCE public.utente_id;
DROP TABLE public.utente;
DROP SEQUENCE public.tipologia_esame_id;
DROP TABLE public.tipologia_di_esame;
DROP TABLE public.risultati_esame;
DROP SEQUENCE public.medico_id;
DROP TABLE public.medico;
DROP SEQUENCE public.esame_id;
DROP TABLE public.esame;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: esame; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE esame (
    id_paziente bigint,
    id_medico bigint,
    data_prenotazione timestamp(0) without time zone,
    data_esame date,
    id bigint NOT NULL,
    id_tipologiaesame bigint
);


ALTER TABLE esame OWNER TO postgres;

--
-- Name: esame_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE esame_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE esame_id OWNER TO postgres;

--
-- Name: medico; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE medico (
    id bigint NOT NULL,
    nome character varying,
    cognome character varying,
    specializzazione character varying
);


ALTER TABLE medico OWNER TO postgres;

--
-- Name: medico_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE medico_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE medico_id OWNER TO postgres;

--
-- Name: risultati_esame; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE risultati_esame (
    id_esame bigint NOT NULL,
    risultati character varying
);


ALTER TABLE risultati_esame OWNER TO postgres;

--
-- Name: tipologia_di_esame; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tipologia_di_esame (
    id bigint NOT NULL,
    nome character varying,
    descrizione character varying,
    prerequisiti character varying,
    indicatore_risultati character varying,
    costo real
);


ALTER TABLE tipologia_di_esame OWNER TO postgres;

--
-- Name: tipologia_esame_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tipologia_esame_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE tipologia_esame_id OWNER TO postgres;

--
-- Name: utente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE utente (
    nome character varying,
    cognome character varying,
    password character varying,
    role character varying,
    username character varying,
    id bigint NOT NULL
);


ALTER TABLE utente OWNER TO postgres;

--
-- Name: utente_id; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE utente_id
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999999999999999
    CACHE 1;


ALTER TABLE utente_id OWNER TO postgres;

--
-- Data for Name: esame; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY esame (id_paziente, id_medico, data_prenotazione, data_esame, id, id_tipologiaesame) FROM stdin;
\.
COPY esame (id_paziente, id_medico, data_prenotazione, data_esame, id, id_tipologiaesame) FROM '$$PATH$$/2144.dat';

--
-- Name: esame_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('esame_id', 1, true);


--
-- Data for Name: medico; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY medico (id, nome, cognome, specializzazione) FROM stdin;
\.
COPY medico (id, nome, cognome, specializzazione) FROM '$$PATH$$/2141.dat';

--
-- Name: medico_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('medico_id', 2, true);


--
-- Data for Name: risultati_esame; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY risultati_esame (id_esame, risultati) FROM stdin;
\.
COPY risultati_esame (id_esame, risultati) FROM '$$PATH$$/2145.dat';

--
-- Data for Name: tipologia_di_esame; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tipologia_di_esame (id, nome, descrizione, prerequisiti, indicatore_risultati, costo) FROM stdin;
\.
COPY tipologia_di_esame (id, nome, descrizione, prerequisiti, indicatore_risultati, costo) FROM '$$PATH$$/2142.dat';

--
-- Name: tipologia_esame_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tipologia_esame_id', 2, true);


--
-- Data for Name: utente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY utente (nome, cognome, password, role, username, id) FROM stdin;
\.
COPY utente (nome, cognome, password, role, username, id) FROM '$$PATH$$/2139.dat';

--
-- Name: utente_id; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('utente_id', 2, true);


--
-- Name: esame_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY esame
    ADD CONSTRAINT esame_pkey PRIMARY KEY (id);


--
-- Name: medico_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY medico
    ADD CONSTRAINT medico_pkey PRIMARY KEY (id);


--
-- Name: risultati_esame_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY risultati_esame
    ADD CONSTRAINT risultati_esame_pkey PRIMARY KEY (id_esame);


--
-- Name: tipologia_di_esame_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tipologia_di_esame
    ADD CONSTRAINT tipologia_di_esame_pkey PRIMARY KEY (id);


--
-- Name: username; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY utente
    ADD CONSTRAINT username UNIQUE (username);


--
-- Name: utente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY utente
    ADD CONSTRAINT utente_pkey PRIMARY KEY (id);


--
-- Name: esame_id_medico_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY esame
    ADD CONSTRAINT esame_id_medico_fkey FOREIGN KEY (id_medico) REFERENCES medico(id);


--
-- Name: esame_id_paziente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY esame
    ADD CONSTRAINT esame_id_paziente_fkey FOREIGN KEY (id_paziente) REFERENCES utente(id);


--
-- Name: esame_id_tipologiaEsame_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY esame
    ADD CONSTRAINT "esame_id_tipologiaEsame_fkey" FOREIGN KEY (id_tipologiaesame) REFERENCES tipologia_di_esame(id);


--
-- Name: risultati_esame_id_esame_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY risultati_esame
    ADD CONSTRAINT risultati_esame_id_esame_fkey FOREIGN KEY (id_esame) REFERENCES esame(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

